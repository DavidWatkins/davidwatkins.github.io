import numpy as np 
import nyud_layers
from PIL import Image
import matplotlib.pyplot as plt

import caffe


def process_image(num, ishha2):
	#Load input image and preprocess for Caffe: cast to float, switch channels RGB->BGR, subtract mean, transpose to C x H x W
	im = Image.open('data/nyud/data/images/img_' + str(num) + '.png')
	in_im_ = np.array(im, dtype=np.float32)
	in_im_ = in_im_[:,:,::-1]
	in_im_ = in_im_.transpose((2,0,1))

	#Load HHA features
	im = Image.open('data/nyud/data/hha2/img_' + str(num) + '.png') if ishha2 else Image.open('data/nyud/data/hha/img_' + str(num) + '.png')
	hha = np.array(im, dtype=np.float32)
	hha = hha.transpose((2,0,1))

	# load net
	net = caffe.Net('nyud-fcn32s-color-hha/test.prototxt', 'nyud-fcn32s-color-hha/nyud-fcn32s-color-hha-heavy.caffemodel', caffe.TEST)
	# shape for input (data blob is N x C x H x W), set data
	net.blobs['color'].reshape(1, *in_im_.shape)
	net.blobs['color'].data[...] = in_im_

	net.blobs['hha'].reshape(1, *hha.shape)
	net.blobs['hha'].data[...] = hha

	# net.blobs['label'].reshape(1, *hha.shape)
	# net.blobs['label'].data[...] = hha

	# run net and take argmax for prediction
	net.forward()
	out = net.blobs['score'].data[0].argmax(axis=0)


	#plt.imshow(out)
	#plt.show()

	fig = plt.figure(frameon=False)
	fig.set_size_inches(8, 6)

	ax = plt.Axes(fig, [0.,0.,1.,1.])
	ax.set_axis_off()
	fig.add_axes(ax)

	ax.imshow(out, aspect='normal')
	suffix = 'hha2' if ishha2 else 'hha'
	fig.savefig('categories/nyudinfer_' + str(num) + suffix + '.png', dpi=100)

for i in range(5002, 5003):
	process_image(i, False)
	process_image(i, True)