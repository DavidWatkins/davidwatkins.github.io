import matlab.engine
from scipy.misc import imsave
import IPython
eng = matlab.engine.start_matlab()
# eng.cd('/home/davidwatkins/rcnn-depth/eccv14-code/',nargout=0)

def handle_img(num):
	prefix = '/home/davidwatkins/fcn.berkeleyvision.org/data/nyud/data/'
	hha_rawdepth_rawdepth = eng.hhaTransform(prefix + 'images/img_' + str(num) + '.png', prefix + 'rawdepth/img_' + str(num) + '.png', prefix + 'rawdepth/img_' + str(num) + '.png')
	imsave('/home/davidwatkins/fcn.berkeleyvision.org/data/nyud/data/hha2/img_' + str(num) + '.png', hha_rawdepth_rawdepth)

for i in range(5450, 6450):
	handle_img(i)
	print(i)
