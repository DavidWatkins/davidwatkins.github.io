#ifndef INC_3_HW1_MAIN_H
#define INC_3_HW1_MAIN_H

#include "GLOptions.h"
#include "GLScene.h"
#include "GLUI.h"
#include "GLController.h"

#include <vector>
#include <iostream>

#endif //INC_3_HW1_MAIN_H
