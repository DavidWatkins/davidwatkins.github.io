# Depth-Renderer
Given an obj file renders a series of pcd files.  Camera properties meant to simulate a Microsoft Kinect v2. 
