import numpy as np
from scipy.misc import imread

total = 0
for i in range(5001, 6450):
	hha = imread('hha/img_' + str(i) + '.png')
	hha2 = imread('hha2/img_' + str(i) + '.png')
	diff = hha - hha2
	avg = np.average(diff)
	print(avg)
	total += avg

total = total / 150
print(total)
