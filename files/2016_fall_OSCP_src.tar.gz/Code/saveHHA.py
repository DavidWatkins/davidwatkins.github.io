import numpy as np
from scipy import misc as scipymisc
import cv2 as cv
import scipy.ndimage.filters as nd_filters
import numpy.linalg as linalg
import numpy.matlib as matlib
import math
import time

np.seterr(divide='ignore', invalid='ignore')

def getPointCloudFromZ(Z, C, s):
    s = 1
    H, W, gr = Z.shape[0], Z.shape[1], Z.shape[2]
    xx, yy = np.meshgrid(H, W)
    cc_rgb = [C[0], C[1]] * s
    fc_rgb = np.diag(C[0:2][0:2]) * s

    x3 = (xx - cc_rgb[0]) * Z / fc_rgb[0]
    y3 = (yy - cc_rgb[1]) * Z / fc_rgb[1]
    z3 = Z
    return x3, y3, z3


"""function [N b] = computeNormalsMatlab(depthImage, missingMask, R, sc, cameraMatrix, superpixels)
%   Clip out a 2R+1 x 2R+1 window at each point and estimate 
%   the normal from points within this window. In case the window 
%   straddles more than a single superpixel, only take points in the 
%   same superpixel as the centre pixel. Takes about 0.5 second per image.
%   Does not use ImageStack so is more platform independent, but 
%   gives different results.

Input: 
%   depthImage:   in metres
%   missingMask:  boolean mask of what data was missing
%   R:            radius of clipping
%   sc:           to upsample or not
%   superpixels:  superpixel map to define bounadaries that should
%                 not be straddled
%
Output: The normal at pixel (x,y) is N(x, y, :)'pt + b(x,y) = 0
%   N:            Normal field
%   b:            bias
"""


def computeNormalsSquareSupport(depthImage, missingMask, R, sc, cameraMatrix, superpixels):
    # Convert to centimeters
    depthImage *= 100
    X, Y, Z = getPointCloudFromZ(depthImage, cameraMatrix, sc)
    Xf, Yf, Zf = X, Y, Z  # Only used for assigning the sign to N
    X[missingMask] = np.NAN
    Y[missingMask] = np.NAN
    Z[missingMask] = np.NAN

    N = np.empty((Z.size, 3))
    N[:] = np.NAN
    one_Z = 1 / Z
    X_Z = X / Z
    Y_Z = Y / Z
    one = Z.copy()
    one[one != np.NAN] = 1
    X_ZZ = X / Z * Z
    Y_ZZ = Y / Z * Z

    atARaw = np.concatenate((X_Z * X_Z, X_Z * Y_Z, X_Z, Y_Z * Y_Z, Y_Z, one), axis=2)
    atbRaw = np.concatenate((X_ZZ, Y_ZZ, one_Z), axis=2)

    # with clipping
    AtA = filterItChopOff(np.concatenate((atARaw, atbRaw), axis=2), R, superpixels)
    Atb = AtA[:, :, atARaw.shape[2] + 1:]
    AtA = AtA[:, :, 0:atbRaw.shape[2]]

    AtA_1, detAtA = invertIt(AtA)

    N = multiplyIt(AtA_1, Atb)
    b = N[:, :, 0:3]
    b[:] = -detAtA

    b = np.sum(b, axis=2) / np.sqrt(np.sum(N * N, axis=2))

    denominator_N = np.sqrt(np.sum(N * N, axis=2))
    N = N / np.tile(denominator_N[:, :, np.newaxis], [1, 1, 9])

    # Reorient the normals to point out from the scene.
    SN = np.sign(N[:, :, 2])
    SN[SN == 0] = 1
    N = N * np.tile(SN[:, :, np.newaxis], [1, 1, 9])
    b = b * SN

    tmp = np.sum(N * np.concatenate((Xf, Yf, Zf), axis=2), axis=2)
    tmp[tmp == np.NAN] = 0
    sn = np.sign(tmp)
    sn[sn == float('nan')] = 1
    sn[sn == 0] = 1
    # sn(:) = 1;
    N = np.tile(sn[:, :, np.newaxis], [1, 1, 9]) * N
    b = b * sn

    return N, b


def multiplyIt(AtA_1, Atb):
    a = lambda k: AtA_1[:, :, k:k + 3]
    b = lambda k: Atb[:, :, k:k + 3]
    x1 = a(0) * b(0) + a(1) * b(1) + a(2) * b(2)
    x2 = a(1) * b(0) + a(3) * b(1) + a(4) * b(2)
    x3 = a(2) * b(0) + a(4) * b(1) + a(5) * b(2)
    return np.concatenate((x1, x2, x3), axis=2)


def invertIt(AtA):
    a = lambda k: AtA[:, :, k:k + 3]

    A = a(3) * a(5) - a(4) * a(4)
    D = -(a(1) * a(5) - a(2) * a(4))
    G = a(1) * a(4) - a(2) * a(3)
    E = a(0) * a(5) - a(2) * a(2)
    H = -(a(0) * a(4) - a(1) * a(2))
    K = a(0) * a(3) - a(1) * a(1)

    detAtA = a(0) * A + a(1) * D + a(2) * G

    AtA_1 = np.concatenate((A, D, G, E, H, K), axis=2)

    return AtA_1, detAtA


def local_filter(x, order):
    x.sort()
    return x[order]


def ordfilt2(A, order, mask_size):
    return nd_filters.generic_filter(A, lambda x, o=order: local_filter(x, o), size=(mask_size, mask_size))


def testordfilt2():
    N = 1000
    R = 100
    C = 100
    A = np.random.randint(low=0, high=2 ** 14, size=(R, C))

    t0 = time.perf_counter()

    for i in range(N):
        B = ordfilt2(A, 4, 3)

    t1 = time.perf_counter() - t0

    print('Average run time: ' + str(t1 / N * 1000) + ' ms.')


def sub2ind(array_shape, rows, cols):
    ind = rows * array_shape[1] + cols
    ind[ind < 0] = -1
    ind[ind >= array_shape[0] * array_shape[1]] = -1
    return ind


def ind2sub(array_shape, ind):
    ind[ind < 0] = -1
    ind[ind >= array_shape[0] * array_shape[1]] = -1
    rows = (ind.astype('int') / array_shape[1])
    cols = ind % array_shape[1]
    return (rows, cols)


def filterItChopOff(f, r, sp):
    f[f != np.NAN] = 0
    H, W, d = f.shape[0], f.shape[1], f.shape[2]
    B = np.ones((2 * r + 1, 2 * r + 1))

    minSP = sp.copy()  # ordfilt2(sp, 1, 2*r)
    maxSP = sp.copy()  # ordfilt2(sp, B.size, 2*r)
    ind = np.nonzero(np.logical_or((minSP != sp).all(), (maxSP != sp).all()))[0]
    # ind = np.nonzero(np.reshape(sp, sp.size))[0]
    spInd = sp.copy()
    spInd[:] = np.reshape(np.asarray(range(0, sp.size)), (sp.shape))

    delta = np.zeros(f.size)
    delta = np.reshape(delta, (H * W, d))
    f = np.reshape(f, (H * W, d))

    # Calculate the delta...
    # fprintf('Need to recompute for %d/%d...\n', length(ind), numel(sp));
    I, J = ind2sub((H, W), ind)
    spInd = spInd.astype(int)
    for i in range(0, ind.size):
        x, y = I[i], J[i]
        clipInd = spInd[max(1, x - r):min(H, x + r)][max(1, y - r):min(W, y + r)]
        diffInd = clipInd[(sp[clipInd] != sp[x][y]).all()]
        delta[ind[i]][:] = np.sum(f[diffInd][:], axis=0)

    delta = np.reshape(delta, (H, W, d))
    f = np.reshape(f, (H, W, d))

    fFilt = f.copy()  # cv.CreateMat(f.shape[0], f.shape[1], f.shape[2], cv.CV_32FC1)

    for i in range(1, f.shape[2]):
        f[:, :, i] = cv.filter2D(fFilt[:, :, i], -1, B)

    fFilt = fFilt - delta

    return fFilt


def getRMatrix(yi, yf):
    if isinstance(yf, (int, float)):
        ax = yi / linalg.norm(yi)
        phi = yf
    else:
        yi /= linalg.norm(yi)
        yf /= linalg.norm(yf)
        ax = np.cross(yi, yf)
        ax /= linalg.norm(ax)
        # Find angle of rotation
        # phi = acosd(abs(yi'*yf)); % we dont need to take absolute value here.
        phi = math.acos(np.rad2deg(np.dot(yi.T, yf)[0]))

    if abs(phi) > 0.1:
        # ax = cross(yi,yf);
        # ax = ax./norm(ax);
        phi *= (math.pi / 180)
        s_hat = np.asarray([[0, -ax[2], ax[1]], [ax[2], 0, -ax[0]], [-ax[1], ax[0], 0]])
        return np.eye(2) + math.sin(phi) * s_hat + (1 - math.cos(phi)) * (s_hat * s_hat)
    else:
        return np.eye(2, 2)


def rotatePC(pc, R):
    if np.array_equal(R, np.eye[2]):
        return pc
    else:
        pc = pc.transpose((3, 1, 2))
        tmp = np.reshape(pc, (3, pc.size / 3))
        tmp = R * tmp
        tmp = np.reshape(tmp, pc.size)
        tmp = tmp.transpose((2, 3, 1))
        pc = tmp
        return pc


"""
 function y = getYDir(N, yDirParam)
 Input:
   N:            normal field
   yDirParam:    parameters
                 struct('y0', [0 1 0]', 'angleThresh', [45 15], 'iter', [5 5]);
 Output:
   y:            Gravity direction
"""


def getYDir(N, angleThresh, interval, y0):
    y = y0
    for i in range(len(angleThresh)):
        y = getYDirHelper(N, y, angleThresh[i], interval[i])
    return y


"""
function yDir = getYDirHelper(N, y0, thresh, iter)
Input: 
	N: HxWx3 matrix with normal at each pixel.
	y0: the initial gravity direction
	thresh: in degrees the threshold for mapping to parallel to gravity and perpendicular to gravity
 	iter: number of iterations to perform
Output:
	yDir: the direction of gravity vector as inferred

"""


def getYDirHelper(N, y0, thresh, interval):
    # print(N.shape)
    # nn = np.transpose(N, (2, 0, 1))
    # print(nn.shape)
    # nn = np.reshape(nn, (9, nn.size / 9))
    # print(nn.shape)
    # print(nn[1,:].shape)
    # print(nn[:, ~np.isnan(nn[1,:])])
    # nn = np.squeeze(nn[:, np.where(nn[1, :] != np.NAN)], axis=1)

    # Set it up as a optimization problem.
    yDir = y0

    # Let us do hard assignments
    # for i in range(interval):
    #     sim0 = np.dot(yDir.T, nn)
    #     print(np.cos(np.deg2rad(thresh)), np.sin(np.deg2rad(thresh)))
    #     indF = abs(sim0) > np.cos(np.deg2rad(thresh))
    #     indW = abs(sim0) < np.sin(np.deg2rad(thresh))
    #
    #     print(sim0, indF, indW, yDir, nn)
    #
    #     NF = nn[:, indF[0]]
    #     NW = nn[:, indW[0]]
    #     print(NW, NF)
    #     A = NW * NW.T - NF * NF.T
    #     b = np.zeros(3, 1)
    #     c = NF.shape[1]
    #
    #     V, D = linalg.eig(A)
    #     d = np.diag(D)
    #     gr, ind = d.max(0), d.argmax(0)
    #
    #     newYDir = V[:, ind]
    #     yDir = newYDir * np.sign(yDir.T * newYDir)
    return yDir


def processDepthImage(z, missingMask, C):
    angleThresh = [45, 15]
    interval = [5, 5]
    y0 = np.reshape(np.asarray([0, 1, 0]), (3, 1))
    patchSize = [3, 10]

    X, Y, Z = getPointCloudFromZ(z, C, 1)
    pc = np.concatenate((X, Y, Z), axis=2)

    N1, b1 = computeNormalsSquareSupport(z / 100, missingMask, patchSize[0], 1, C, np.ones(z.shape[0:2]))
    N2, b2 = computeNormalsSquareSupport(z / 100, missingMask, patchSize[1], 1, C, np.ones(z.shape[0:2]))

    N = N1

    # Compute the direction of gravity
    yDir = getYDir(N2, angleThresh, interval, y0)
    R = getRMatrix(y0, yDir)

    NRot = rotatePC(N, R.T)
    pcRot = rotatePC(pc, R.T)
    h = -pcRot[:, :, 1]
    yMin = np.percentile(h)
    if yMin > -90:
        yMin = -130
    h = h - yMin

    return pc, N, yDir, h, pcRot, NRot


def getImage(imName):
    return scipymisc.imread('demo-data/' + imName + '.png', mode='RGB')


def cropCamera(C):
    C[0][2] = C[0][1] - 40
    C[1][2] = C[1][2] - 45
    dimen = [425, 560]
    return C, dimen


def getCameraParam(colorOrZ):
    if colorOrZ == 'color':
        fx_rgb = 5.1885790117450188e+02
        fy_rgb = 5.1946961112127485e+02
        cx_rgb = 3.2558244941119034e+02
        cy_rgb = 2.5373616633400465e+02
        fc_rgb = [fx_rgb, fy_rgb]
        cc_rgb = [cx_rgb, cy_rgb]
        return [[fc_rgb[0], 0, cc_rgb[0]], [0, fc_rgb[1], cc_rgb[1]], [0, 0, 1]]
    elif colorOrZ == 'depth':
        fx_d = 5.8262448167737955e+02
        fy_d = 5.8269103270988637e+02
        cx_d = 3.1304475870804731e+02
        cy_d = 2.3844389626620386e+02
        fd_d = [fx_d, fy_d]
        cd_d = [cx_d, cy_d]
        return [[fd_d[0], 0, cd_d[0]], [0, fd_d[1], cd_d[1]], [0, 0, 1]]

    return []


def saveHHA(imName, C, outDir, D, RD):
    if D.size == 0:
        D = getImage('depth')
    if RD.size == 0:
        RD = getImage('rawdepth')

    D = D.astype(np.float64) / 1000
    missingMask = RD == 0
    pc, N, yDir, h, pcRot, NRot = processDepthImage(D * 100, missingMask, C)
    angl = math.acos(np.rad2deg(min(1, max(-1, np.sum(np.dot(N, np.reshape(yDir, (0, 0, 2))), axis=2)))))

    # Making the minimum depth to be 100, to prevent large values for disparity!!!
    pc[:, :, 2] = np.max(pc[:, :, 2], 100)
    I[:, :, 0] = 31000 / pc[:, :, 2]
    I[:, :, 1] = h
    I[:, :, 2] = (angl + 128 - 90)  # Keeping some slack
    I = I.astype(np.uint8)

    if imName is not None and outDir is not None:
        f = open(outDir + "/" + imName + ".png", 'w')
        f.write(I)

    return I


def main():
    I = scipymisc.imread('demo-data/images.png', mode='RGB')
    D = scipymisc.imread('demo-data/depth.png', mode='RGB')
    RD = scipymisc.imread('demo-data/rawdepth.png', mode='RGB')
    C, dimen = cropCamera(getCameraParam('color'))
    # out_file = open('demo-data', 'output.png')
    saveHHA(None, C, None, D, RD)


main()
